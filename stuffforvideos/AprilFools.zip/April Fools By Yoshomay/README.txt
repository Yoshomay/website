How to use, you need a vanilla blank rom of SM64 because I can't legally distribute it. 

Also you need the tool Flips (included in the .zip)

Open flips, click "Apply Patch", select the patch included in the .zip, select the vanilla rom, click save, and boom.

Note, if you're using Project64 you MUST set the ram amount to 8mb. To do that, open the rom in Project64, press "Options" at the top, press "Configuration", click on "Config: {rom name}" on the left, then there's "Memory size:", set that to 8mb, then reload the rom.