How to use, you need a vanilla blank rom of Super Mario World because I can't legally distribute it. 

Open flips, click "Apply Patch", select the patch included in the .zip, select the vanilla rom, click save, and boom.

Credits:

Creator, Yoshomay

Tools used:
Lunar Magic, level editor
Graphics Editor, graphics editor