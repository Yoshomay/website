How to use, you need a vanilla blank rom of Mario World because I can't legally distribute it. 

Also you need the tool Flips (included in the .zip)

Open flips, click "Apply Patch", select the patch included in the .zip, select the vanilla rom, click save, and boom.